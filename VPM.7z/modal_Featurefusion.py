import torch
import torch.nn as nn

class PressureFeatureExtractor(nn.Module):
   
    def __init__(self, in_channels=1, base_channels=32):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(in_channels, base_channels, 3, padding=1),
            nn.LeakyReLU(0.2),
            nn.Conv2d(base_channels, base_channels*2, 3, padding=1),
            nn.LeakyReLU(0.2),
            nn.Conv2d(base_channels*2, base_channels*4, 3, padding=1),
            nn.LeakyReLU(0.2),
            nn.Conv2d(base_channels*4, base_channels*8, 3, padding=1),
            nn.LeakyReLU(0.2),
            nn.Conv2d(base_channels*8, base_channels*16, 3, padding=1),
            nn.LeakyReLU(0.2),
        )
        self.final_conv = nn.Conv2d(base_channels*16, 64, 1)

    def forward(self, x):
        batch, time = x.shape[:2]
        x = x.view(batch*time, 1, *x.shape[2:])  
        features = self.features(x)  # [batch*time, 64, 10, 10]
        return features.view(batch, time, *features.shape[1:]) 

class VisionFeatureExtractor(nn.Module):

    def __init__(self, in_channels=3, base_channels=32):
        super().__init__()
        self.encoder = nn.Sequential(
    
            nn.Conv3d(in_channels, base_channels, (3,3,3), padding=1),
            nn.LeakyReLU(0.2),
            nn.Conv3d(base_channels, base_channels*2, (3,3,3), padding=1),
            nn.LeakyReLU(0.2),
            nn.Conv3d(base_channels*2, base_channels*4, (3,3,3), stride=(1,2,2), padding=1),
            nn.LeakyReLU(0.2),
            nn.Conv3d(base_channels*4, base_channels*8, (3,3,3), padding=1),
            nn.LeakyReLU(0.2),
            nn.Conv3d(base_channels*8, 64, (3,3,3), padding=1),
        )

    def forward(self, x):
        """(batch, time, C, H, W)"""
        x = x.permute(0, 2, 1, 3, 4)  
        return self.encoder(x)  

class FeatureFusionModel(nn.Module):

    def __init__(self, num_keypoints=17, depth_dim=9):
        super().__init__()
        self.depth_dim = depth_dim

        self.pressure_extractor = PressureFeatureExtractor()
        self.vision_extractor = VisionFeatureExtractor()
        

        self.regressor = nn.Sequential(
            nn.Conv3d(128+1, 256, 3, padding=1),  # +1 depth
            nn.LeakyReLU(0.2),
            nn.ConvTranspose3d(256, 128, 3, stride=2, padding=1, output_padding=1),
            nn.LeakyReLU(0.2),
            nn.ConvTranspose3d(128, 64, 3, stride=2, padding=1, output_padding=1),
            nn.LeakyReLU(0.2),
        )
        self.fc = nn.Sequential(
            nn.AdaptiveAvgPool3d((1, 1, 1)),  
            nn.Flatten(),
            nn.Linear(num_keypoints, 512),
            nn.LeakyReLU(0.2),
            nn.Linear(512, num_keypoints * 3)
        )

    def _add_depth_channel(self, x):
  
        batch, channels, d, h, w = x.shape
        z_coords = torch.linspace(0, 1, d, device=x.device).view(1, 1, d, 1, 1).expand(batch, 1, d, h, w)
        return torch.cat([x, z_coords], dim=1)

    def _expand_to_3d(self, pressure_feat):
  
        batch, time, C, H, W = pressure_feat.shape
 
        expanded = pressure_feat.unsqueeze(3).expand(-1, -1, -1, self.depth_dim, -1, -1)
        return expanded.reshape(batch, time*C, self.depth_dim, H, W)

    def forward(self, rgb_frames, pressure_frames):
      
        
        pressure_feat = self.pressure_extractor(pressure_frames)  # (batch, time, 64, 10, 10)
        vision_feat = self.vision_extractor(rgb_frames)  # (batch, 64, time, H', W')
        
       
        pressure_3d = self._expand_to_3d(pressure_feat)  # (batch, time*64, D, 10, 10)
        vision_3d = vision_feat.permute(0, 2, 1, 3, 4)  # (batch, time, 64, H', W')
        
        pressure_3d=self._add_depth_channel(pressure_3d )

        combined = torch.cat([pressure_3d, vision_3d], dim=2) 
        combined = combined.permute(0, 2, 1, 3, 4) 
  
        features = self.regressor(combined)

        coordinates = self.fc(features)

        return coordinates.view(-1, self.num_keypoints, 3)

