import torch
import numpy as np
import math

class HeatmapGenerator3D:
    def __init__(self, xyz_range, heatmap_size, sigma=1.0, device='cuda'):
        """
        Args:
            xyz_range: [[x_min, x_max], [y_min, y_max], [z_min, z_max]]
            heatmap_size: [depth, height, width] 
            sigma: 
        """
        self.device = device
        self.xyz_range = torch.tensor(xyz_range, dtype=torch.float32, device=device)
        self.heatmap_size = torch.tensor(heatmap_size, dtype=torch.float32, device=device)
        self.sigma = sigma

        z, y, x = torch.meshgrid(
            torch.linspace(0, 1, int(heatmap_size[0]), device=device),
            torch.linspace(0, 1, int(heatmap_size[1]), device=device),
            torch.linspace(0, 1, int(heatmap_size[2]), device=device),
            indexing='ij'
        )
        self.grid = torch.stack([x, y, z], dim=-1)  # [D, H, W, 3]
        

        self.resolution = (self.xyz_range[:, 1] - self.xyz_range[:, 0]) / self.heatmap_size
        
    def _normalize_coords(self, keypoints):
    
        return (keypoints - self.xyz_range[:, 0]) / (self.xyz_range[:, 1] - self.xyz_range[:, 0])
    
    def _gaussian(self, distance):

        return torch.exp(-0.5 * (distance**2) / (self.sigma**2)) / (self.sigma * math.sqrt(2*math.pi))
    
    def _create_heatmap_batch(self, norm_keypoints):
        """
        Args:
            norm_keypoints: [Batch, Num_Joints, 3] 
        Returns:
            heatmaps: [Batch, Num_Joints, D, H, W]
        """
        batch_size, num_joints, _ = norm_keypoints.shape

        grid = self.grid.unsqueeze(0).unsqueeze(0)  # [1, 1, D, H, W, 3]
        keypoints = norm_keypoints.view(batch_size, num_joints, 1, 1, 1, 3)  # [B, J, 1, 1, 1, 3]
        

        distances = torch.norm(grid - keypoints, dim=-1)  # [B, J, D, H, W]

        heatmaps = self._gaussian(distances)

        heatmaps = heatmaps.view(batch_size, num_joints, -1)
        heatmaps = torch.softmax(heatmaps/0.25, dim=-1)  # 保持与原代码相同的缩放因子
        heatmaps = heatmaps.view(batch_size, num_joints, *self.heatmap_size.int().tolist())
        
        return heatmaps
    
    def __call__(self, keypoints):
        """
        Args:
            keypoints: [Batch, Frames, Num_Joints, 3] 原始坐标
        Returns:
            heatmaps: [Batch, Frames, Num_Joints, D, H, W]
        """

        keypoints = keypoints.to(self.device).float()
        

        norm_keypoints = self._normalize_coords(keypoints)

        batch_size, num_frames = keypoints.shape[:2]
        heatmaps = []
        
        for t in range(num_frames):
            frame_heatmaps = self._create_heatmap_batch(norm_keypoints[:, t])
            heatmaps.append(frame_heatmaps)
            
        return torch.stack(heatmaps, dim=1)


