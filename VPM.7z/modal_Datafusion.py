import torch
import torch.nn as nn
import torch.nn.functional as F

class PressureProcessor(nn.Module):
    def __init__(self, output_size=(512, 512)):
        super().__init__()
        self.upsample = nn.Upsample(size=output_size, mode='bilinear', align_corners=False)
        
    def forward(self, pressure):
        batch_size, timesteps = pressure.shape[:2]
        pressure = pressure.view(batch_size * timesteps, 1, 13, 13)
        pressure = self.upsample(pressure)
        return pressure.view(batch_size, timesteps, 1, *pressure.shape[-2:])

class MultimodalPoseEstimator(nn.Module):
    def __init__(self, 
                 image_size=(512, 512),
                 num_frames=10,
                 num_keypoints=17,
                 hidden_dims=[64, 128, 256, 512, 1024]):
        super().__init__()
        self.num_keypoints = num_keypoints
        
        self.pressure_processor = PressureProcessor(image_size)
        
        # Encoder remains unchanged
        self.encoder = nn.Sequential(
            *self._build_conv_block(4, hidden_dims[0]),
            *self._build_conv_block(hidden_dims[0], hidden_dims[1]),
            *self._build_conv_block(hidden_dims[1], hidden_dims[2], stride=2),
            *self._build_conv_block(hidden_dims[2], hidden_dims[3]),
            *self._build_conv_block(hidden_dims[3], hidden_dims[4]),
        )
        
        # Revised decoder with symmetrical structure
        self.decoder = nn.Sequential(
            *self._build_conv_block(hidden_dims[4], hidden_dims[3]),
            *self._build_conv_block(hidden_dims[3], hidden_dims[2]),
            *self._build_conv_block(hidden_dims[2], hidden_dims[1], stride=2, transpose=True),
            *self._build_conv_block(hidden_dims[1], hidden_dims[0]),
            nn.Conv3d(hidden_dims[0], num_keypoints, kernel_size=3, padding=1)
        )
        
        # Adaptive pooling and FC layer for coordinate regression
        self.fc = nn.Sequential(
            nn.AdaptiveAvgPool3d((1, 1, 1)),  
            nn.Flatten(),
            nn.Linear(num_keypoints, 512),
            nn.LeakyReLU(0.2),
            nn.Linear(512, num_keypoints * 3)
        )
    
    def _build_conv_block(self, in_ch, out_ch, stride=1, transpose=False):
        layers = []
        if transpose:

            layers.append(
                nn.ConvTranspose3d(in_ch, out_ch, kernel_size=3, 
                                  stride=stride, padding=1, output_padding=1)
            )
        else:
            layers.append(
                nn.Conv3d(in_ch, out_ch, kernel_size=3, stride=stride, padding=1)
            )
        layers.append(nn.LeakyReLU(0.2))
        return layers
    
    def forward(self, images, pressures):
        pressures = self.pressure_processor(pressures)
        x = torch.cat([images, pressures], dim=2)      # (B, T, 4, H, W)
        x = x.permute(0, 2, 1, 3, 4)                   # (B, C, T, H, W)
        
        features = self.encoder(x)
        features1 = self.decoder(features)
        coordinates = self.fc(features1)
        return coordinates.view(-1, self.num_keypoints, 3)