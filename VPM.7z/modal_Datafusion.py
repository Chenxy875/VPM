import torch
import torch.nn as nn
import torch.nn.functional as F

class PressureProcessor(nn.Module):
    def __init__(self, output_size=(512, 512)):
        super().__init__()
        self.upsample = nn.Upsample(size=output_size, mode='bilinear', align_corners=False)
        
    def forward(self, pressure):
        # pressure shape: (batch, time, 13, 13)
        batch_size, timesteps = pressure.shape[:2]
        
        # Reshape and upsample
        pressure = pressure.view(batch_size * timesteps, 1, 13, 13)
        pressure = self.upsample(pressure)  # (batch*time, 1, H, W)
        return pressure.view(batch_size, timesteps, 1, *pressure.shape[-2:])

class MultimodalPoseEstimator(nn.Module):
    def __init__(self, 
                 image_size=(512, 512),
                 num_frames=10,
                 num_keypoints=17,
                 hidden_dims=[64, 128, 256, 512, 1024]):
        super().__init__()
        
    
        self.pressure_processor = PressureProcessor(image_size)
        
 
        self.encoder = nn.Sequential(
            *self._build_conv_block(4, hidden_dims[0]),      # 输入通道：RGB(3) + Pressure(1)
            *self._build_conv_block(hidden_dims[0], hidden_dims[1]),
            *self._build_conv_block(hidden_dims[1], hidden_dims[2], stride=2),
            *self._build_conv_block(hidden_dims[2], hidden_dims[3]),
            *self._build_conv_block(hidden_dims[3], hidden_dims[4]),
        )
        

        self.decoder = nn.Sequential(
            *self._build_conv_block(hidden_dims[4], hidden_dims[2]),
            *self._build_conv_block(hidden_dims[2], hidden_dims[1]),
            nn.ConvTranspose3d(hidden_dims[1], hidden_dims[0], 
                              kernel_size=3, stride=2, 
                              padding=1, output_padding=1),
            nn.LeakyReLU(0.2),
            nn.Conv3d(hidden_dims[0], num_keypoints, kernel_size=3, padding=1),
            nn.Sigmoid()
        )
    
    def _build_conv_block(self, in_ch, out_ch, stride=1):
        return [
            nn.Conv3d(in_ch, out_ch, kernel_size=3, 
                     stride=stride, padding=1),
            nn.LeakyReLU(0.2)
        ]
    
    def forward(self, images, pressures):
        """
        Args:
            images: (batch, timesteps, 3, H, W)
            pressures: (batch, timesteps, 13, 13)
        Returns:
            3D confidence maps: (batch, num_keypoints, D, H, W)
        """
 
        pressures = self.pressure_processor(pressures)  # (batch, T, 1, H, W)

        x = torch.cat([images, pressures], dim=2)      # (batch, T, 4, H, W)
        

        x = x.permute(0, 2, 1, 3, 4)  # (batch, channels, time, H, W)
        
 
        features = self.encoder(x)
        
  
        confidence_maps = self.decoder(features)
        return confidence_maps